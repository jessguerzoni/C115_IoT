#include <WiFi.h>
#include <PubSubClient.h>

#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

//Definição do OLED


#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64

Adafruit_SSD1306 display(
  SCREEN_WIDTH,
  SCREEN_HEIGHT,
  &Wire,
  -1
);

//Definição dos LEDs
#define BLUE_LED 18
#define RED_LED 19

//Configuração do WiFi
const char* ssid = "Wokwi-GUEST";
const char* password = "";

//Configuração MQTT
const char* mqtt_server =
  "broker.hivemq.com";

const char* TOPICO_TEMP =
  "incubadora/temperatura";

WiFiClient espClient;
PubSubClient client(espClient);

void reconnect()
{
  while (!client.connected())
  {
    Serial.print(
      "Conectando MQTT..."
    );

    if (
      client.connect(
        "ESP32_INCUBADORA"
      )
    )
    {
      Serial.println(
        " conectado!"
      );

      client.subscribe(
        TOPICO_TEMP
      );
    }
    else
    {
      Serial.print(
        " erro="
      );

      Serial.println(
        client.state()
      );

      delay(2000);
    }
  }
}


//Variaveis

float temperatura = 0.0;


void setupWifi()
{
  Serial.print("Conectando WiFi");

  WiFi.begin(
    ssid,
    password
  );

  while (
    WiFi.status() != WL_CONNECTED
  )
  {
    delay(500);
    Serial.print(".");
  }

  Serial.println();
  Serial.println("WiFi conectado");
}

void callback(
  char* topic,
  byte* payload,
  unsigned int length
)
{
  String mensagem = "";

  for (
    int i = 0;
    i < length;
    i++
  )
  {
    mensagem +=
      (char)payload[i];
  }

  temperatura =
    mensagem.toFloat();

  Serial.print(
    "Temperatura recebida: "
  );

  Serial.println(
    temperatura
  );
}



void setup()
{
  Serial.begin(115200);

  pinMode(
    BLUE_LED,
    OUTPUT
  );

  pinMode(
    RED_LED,
    OUTPUT
  );

  Wire.begin(
    21,
    22
  );

  if (
    !display.begin(
      SSD1306_SWITCHCAPVCC,
      0x3C
    )
  )
  {
    Serial.println(
      "Falha OLED"
    );

    while (true);
  }

  display.clearDisplay();
  display.display();

  setupWifi();

  client.setServer(
    mqtt_server,
    1883
  );

  client.setCallback(
    callback
  );

  Serial.println(
    "Leitura em processo"
  );
}

void loop()
{
  if (!client.connected())
  {
    reconnect();
  }

  client.loop();

  // LEDs

  if (
    temperatura >= 36.0 &&
    temperatura <= 37.5
  )
  {
    digitalWrite(
      BLUE_LED,
      HIGH
    );

    digitalWrite(
      RED_LED,
      LOW
    );
  }
  else
  {
    digitalWrite(
      BLUE_LED,
      LOW
    );

    digitalWrite(
      RED_LED,
      HIGH
    );
  }

  // Serial

  Serial.print("Temperatura: ");
  Serial.println(
    temperatura
  );

  // Configuração do OLED

  display.clearDisplay();

  display.setTextSize(1);
  display.setTextColor(
    SSD1306_WHITE
  );

  display.setCursor(
    0,
    0
  );

  display.println(
    "---Leitor de Temperatura---"
  );

  display.setCursor(
    0,
    18
  );

  display.print(
    "Temp: "
  );

  display.print(
    temperatura,
    1
  );

  display.println(
    " C"
  );

  display.setCursor(
    0,
    40
  );

  if (
    temperatura >= 36.0 &&
    temperatura <= 37.5
  )
  {
    display.println(
      "Temperatura Normal"
    );
  }
  else
  {
    display.println(
      "ALERTA! Valor fora do limite permitido"
    );
  }

  display.display();

  delay(500);
}